<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Credenciais</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <div class="topo">
    <h1>Gerenciamento de Credenciais</h1>
    <br>
    <p>Insira abaixo as credenciais para que possamos configurar corretamente o banco de dados do seu sistema.</p>
    </div>
    <br>
    <form action="processar_credenciais.php" method="POST">
        <div class="form-group">
            <label for="servidor">Servidor:</label>
            <input type="text" class="form-control" id="servidor" name="servidor" placeholder="Insira aqui o nome do servidor ou endereço de acesso" >
        </div>
        <div class="form-group">
            <label for="usuario">Usuário:</label>
            <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Insira o usuário do seu sistema (nos sistemas locais é root)" >
        </div>
        <div class="form-group">
            <label for="senha">Senha:</label>
            <input type="password" class="form-control" id="senha" name="senha" placeholder="A senha de acesso de seu servidor (nos locais, normalmente é em branco)">
        </div>
        <div class="form-group">
            <label for="base">Base:</label>
            <input type="text" class="form-control" id="base" name="base" placeholder="Nome da Base de Dados que você vai conectar" >
        </div>
        <div class="topo">
        <button type="submit" class="btn btn-custom">Criar banco de dados</button>
        </div>
    </form>

    <div class="footer">
        <p>&copy; 2025 Sistema Devisate</p>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
